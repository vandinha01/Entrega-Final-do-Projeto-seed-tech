package com.seedtech_pi.controller;

import com.seedtech_pi.model.Armazem;
import com.seedtech_pi.repository.ArmazemRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/armazens")
@CrossOrigin(origins = "*")
public class ArmazemController {

    private final ArmazemRepository repo;

    public ArmazemController(ArmazemRepository repo) {
        this.repo = repo;
    }

    @GetMapping
    public List<Armazem> listar() {
        return repo.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Armazem> buscar(@PathVariable Integer id) {
        Optional<Armazem> a = repo.findById(id);
        return a.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Armazem> criar(@RequestBody Armazem armazem) {
        Armazem salvo = repo.save(armazem);
        return ResponseEntity.ok(salvo);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Armazem> atualizar(@PathVariable Integer id, @RequestBody Armazem dados) {
        return repo.findById(id)
                .map(existing -> {
                    existing.setNome(dados.getNome());
                    existing.setLocalizacao(dados.getLocalizacao());
                    existing.setCapacidadeKg(dados.getCapacidadeKg());
                    repo.save(existing);
                    return ResponseEntity.ok(existing);
                }).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> apagar(@PathVariable Integer id) {
        if (!repo.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        repo.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
