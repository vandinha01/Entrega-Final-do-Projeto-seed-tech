package com.seedtech_pi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SeedtechPiApplication {
    public static void main(String[] args) {
        SpringApplication.run(SeedtechPiApplication.class, args);
    }
}
