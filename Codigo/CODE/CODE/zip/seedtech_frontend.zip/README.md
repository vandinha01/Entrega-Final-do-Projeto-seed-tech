# SeedTech Frontend Simples

Frontend mínimo em HTML+JS para consumir o backend.

## Rodar
Abra `index.html` no navegador.

## Endpoints usados
- GET /armazens
- POST /armazens
- DELETE /armazens/{id}
